package com.example.sareur;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    // Offline fixed rate: 1 EUR = 4.40 SAR => 1 SAR ≈ 0.22727 EUR
    private static final double SAR_PER_EUR = 4.40;

    TextView result;
    EditText input;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 45, 32, 24);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("SAR  →  EUR");
        title.setTextSize(30); title.setTextColor(Color.rgb(20,20,20));
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));

        TextView rate = new TextView(this);
        rate.setText("OFFLINE • 1 € = 4.40 SAR");
        rate.setTextSize(16); rate.setTextColor(Color.DKGRAY);
        rate.setGravity(Gravity.CENTER);
        root.addView(rate, new LinearLayout.LayoutParams(-1, 55));

        input = new EditText(this);
        input.setHint("Ποσό σε SAR");
        input.setInputType(2 | 8192);
        input.setTextSize(26);
        input.setGravity(Gravity.CENTER);
        root.addView(input, new LinearLayout.LayoutParams(-1, 90));

        Button convert = new Button(this);
        convert.setText("ΜΕΤΑΤΡΟΠΗ");
        convert.setTextSize(18);
        root.addView(convert, new LinearLayout.LayoutParams(-1, 65));

        result = new TextView(this);
        result.setText("0,00 €");
        result.setTextSize(42); result.setTextColor(Color.rgb(21,101,192));
        result.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, 130);
        rp.topMargin = 25; root.addView(result, rp);

        TextView quick = new TextView(this);
        quick.setText("Γρήγορα ποσά");
        quick.setTextSize(18); quick.setGravity(Gravity.CENTER);
        root.addView(quick, new LinearLayout.LayoutParams(-1, 55));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        int[] amounts = {50,100,200,300,500,1000};
        for (int a : amounts) {
            Button x = new Button(this);
            x.setText(String.valueOf(a));
            x.setOnClickListener(v -> { input.setText(String.valueOf(a)); convert.performClick(); });
            row.addView(x, new LinearLayout.LayoutParams(0, 60, 1));
        }
        root.addView(row);

        TextView note = new TextView(this);
        note.setText("\nΗ ισοτιμία είναι αποθηκευμένη μέσα στην εφαρμογή και λειτουργεί χωρίς internet.");
        note.setTextSize(14); note.setTextColor(Color.GRAY); note.setGravity(Gravity.CENTER);
        root.addView(note, new LinearLayout.LayoutParams(-1, 100));

        convert.setOnClickListener(v -> calculate());
        input.setOnEditorActionListener((v, action, e) -> { calculate(); return true; });

        setContentView(root);
    }

    private void calculate() {
        String s = input.getText().toString().trim().replace(',', '.');
        try {
            double sar = Double.parseDouble(s);
            double eur = sar / SAR_PER_EUR;
            result.setText(String.format(Locale.GERMANY, "%.2f €", eur));
        } catch(Exception e) { result.setText("—"); }
    }
}
