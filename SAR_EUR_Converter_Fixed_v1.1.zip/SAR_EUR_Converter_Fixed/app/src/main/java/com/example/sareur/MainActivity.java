package com.example.sareur;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.InputType;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final double SAR_PER_EUR = 4.40;
    private EditText input;
    private TextView result;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(Color.WHITE);

        TextView title = text("SAR  →  EUR", 30, Color.rgb(25,25,25), true);
        root.addView(title, lp(-1, 58));

        TextView offline = text("OFFLINE  •  1 € = 4.40 SAR", 16, Color.DKGRAY, false);
        root.addView(offline, lp(-1, 42));

        input = new EditText(this);
        input.setHint("Ποσό σε SAR");
        input.setTextSize(24);
        input.setGravity(Gravity.CENTER);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout.LayoutParams ip = lp(-1, 70);
        ip.topMargin = 12;
        root.addView(input, ip);

        Button convert = new Button(this);
        convert.setText("ΜΕΤΑΤΡΟΠΗ");
        convert.setTextSize(16);
        LinearLayout.LayoutParams cp = lp(-1, 58);
        cp.topMargin = 10;
        root.addView(convert, cp);

        result = text("0,00 €", 42, Color.rgb(21,101,192), true);
        LinearLayout.LayoutParams rp = lp(-1, 82);
        rp.topMargin = 18;
        root.addView(result, rp);

        TextView quick = text("Γρήγορα ποσά (SAR)", 17, Color.DKGRAY, true);
        LinearLayout.LayoutParams qp = lp(-1, 42);
        qp.topMargin = 8;
        root.addView(quick, qp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        int[] amounts = {50,100,200,300,500,1000};
        for (int amount : amounts) {
            Button b = new Button(this);
            b.setText(String.valueOf(amount));
            b.setTextSize(13);
            b.setPadding(0,0,0,0);
            b.setOnClickListener(v -> {
                input.setText(String.valueOf(amount));
                calculate();
            });
            row.addView(b, new LinearLayout.LayoutParams(0, 54, 1));
        }
        root.addView(row, lp(-1, 60));

        TextView note = text("Η ισοτιμία είναι αποθηκευμένη στην εφαρμογή.\nΛειτουργεί χωρίς internet.", 14, Color.GRAY, false);
        LinearLayout.LayoutParams np = lp(-1, 65);
        np.topMargin = 14;
        root.addView(note, np);

        convert.setOnClickListener(v -> calculate());
        input.setOnEditorActionListener((v, action, event) -> { calculate(); return true; });

        setContentView(root);
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void calculate() {
        String s = input.getText().toString().trim().replace(',', '.');
        try {
            double sar = Double.parseDouble(s);
            double eur = sar / SAR_PER_EUR;
            result.setText(String.format(Locale.GERMANY, "%.2f €", eur));
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        } catch (Exception e) {
            result.setText("0,00 €");
        }
    }
}
